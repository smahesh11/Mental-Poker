#include <iostream>
#include <cstring>      // Needed for memset
#include <sys/socket.h> // Needed for the socket functions
#include <netdb.h>      // Needed for the socket functions
#include <unistd.h>
#include<vector>
#include<time.h>
#include<stdlib.h>
#include<math.h>
#include<fstream>



using namespace std;

long  long int pickRandomPrimes()
{
    vector<string> primeVector;
    srand (time(NULL));
    long long int   countOfPrimes=0;

    //get primes file size
    string line;
        ifstream primesfile1("primes.txt");

        if(primesfile1.is_open()){
            while(!primesfile1.eof()){
                getline(primesfile1,line);
               // cout<< line << endl;
                countOfPrimes++;
            }
            primesfile1.close();
        }

    string num;
    //read from file and store in array
    ifstream readPrimes ("primes.txt");
     if (readPrimes.is_open())
     {
     while ( getline (readPrimes,num) )
     {
     // cout << line << '\n';
      primeVector.push_back(num);
     }
     readPrimes.close();
     }

     long long int pos1=rand()%(countOfPrimes-1);
     //long int pos2=rand()%(countOfPrimes-1);

      string str1=primeVector[pos1];
    //  cout<<""<<str1;
     long  long int pnum1 = atoi(str1.c_str());
   //  cout<<pnum1;
      return pnum1;
}



//method to calculate gcd for public key
unsigned GCD(unsigned u, unsigned v) {
    while ( v != 0) {
        unsigned r = u % v;
        u = v;
        v = r;
    }
    return u;
}

//method to generate public key
long long int generateEncryptionKey(long long int a, long long int b)
{
    return rand()%(b-a)+a;
}

//method to perform fing a^b mod c
long long int modPow(long long int card,long long int skey, long long int prime)
{
    long long int y = 1;
    long long int u = card % prime;

    while(skey != 0){
       if(skey % 2 == 1) y = (y*u) % prime;
       skey = floor(skey/2);
       u = (u*u) % prime;
    }
    return y;
}

//method to generate decryption key
long long int generateDecryptionKey(long long int a, long long int m)
{
        a %= m;
        for(long long int x = 1; x < m; x++) {
            if((a*x) % m == 1) return x;
        }

}

//method to encrypt one message
long long int encryptMsg(long long int card,long long int skey, long long int prime)
{
    long long int encryptedMsg = modPow(card,skey,prime);
    return encryptedMsg;
}

//method to decrypt one message
long long int decryptMsg(long long int card,long long int dkey, long long int prime)
{
    long long int encryptedMsg = modPow(card,dkey,prime);
    return encryptedMsg;
}

//method to generate deck of cards
vector<long long int> generateDeck()
{
    vector <long long int> deckOfCards;
    for(int i=48;i<100;i++)
    {
         deckOfCards.push_back(i);
    }

    return deckOfCards;
}

//method to shuffele cards
vector<long long int> ShuffeledCards()
{
    vector <long long int> arr=generateDeck();
    srand ( time(NULL) );

       // Start from the last element and swap one by one. We don't
       // need to run for the first element that's why i > 0

           for (long int i=0; i<52; i++)
           {
                long int r = rand() % 52;  // generate a random position
                long int temp = arr[i];
                arr[i] = arr[r];
                arr[r] = temp;
           }


    return arr;
}

//method to encrypt multiple cards
vector<long long int> EncryptAllCards(vector<long long int> cards, long long int publicKey, long long int primeNumber)
{
     vector<long long int> encyptedcardsAll;
     cards=ShuffeledCards();

     for(int i=0;i<cards.size();i++)
     {
     encyptedcardsAll.push_back(modPow(cards[i],publicKey, primeNumber));
     }

     return encyptedcardsAll;
}

//method to decrypt multiple cards
vector<long long int> DecryptAllCards(vector<long long int> encryptedCards, long long int privateKey, long long int phi)
{
    vector<long long int> decryptedcardsAll;

    for(int i=0;i<encryptedCards.size();i++)
    {
    decryptedcardsAll.push_back(modPow(encryptedCards[i],privateKey, phi));
    }

    return decryptedcardsAll;
}





int main()
{

    int status;
    struct addrinfo host_info;       // The struct that getaddrinfo() fills up with data.
    struct addrinfo *host_info_list; // Pointer to the to the linked list of host_info's.


    memset(&host_info, 0, sizeof host_info);

    std::cout << "Setting up the structs..."  << std::endl;

    host_info.ai_family = AF_UNSPEC;     // IP version not specified. Can be both.
    host_info.ai_socktype = SOCK_STREAM; // Use SOCK_STREAM for TCP or SOCK_DGRAM for UDP.

    // Now fill up the linked list of host_info structs with google's address information.
    status = getaddrinfo("127.0.0.1", "5556", &host_info, &host_info_list);

    if (status != 0)  std::cout << "getaddrinfo error" << gai_strerror(status) ;


    std::cout << "Creating a socket..."  << std::endl;
    int socketfd ; // The socket descripter
    socketfd = socket(host_info_list->ai_family, host_info_list->ai_socktype,
                      host_info_list->ai_protocol);
    if (socketfd == -1)  std::cout << "socket error " ;


    std::cout << "Connect()ing..."  << std::endl;
    status = connect(socketfd, host_info_list->ai_addr, host_info_list->ai_addrlen);
    if (status == -1)  std::cout << "connect error" ;

    //*********************************************************************************************
    //Starting the game
    std::cout << "send()ing message..."  << std::endl;
    char *msg = "Alice :\t Hi Bob!! Ready to start the game??";
    int len;
    ssize_t bytes_sent;
    len = strlen(msg);
    bytes_sent = send(socketfd, msg, len, 0);

    //*********************************************************************************************
    //Recieving game starting msg-yes sure
    std::cout << "Waiting to recieve data..."  << std::endl;
    ssize_t bytes_recieved;
    char incomming_data_buffer[1000];
    bytes_recieved = recv(socketfd, incomming_data_buffer,1000, 0);
    cout<<"On Client Side receiving Data"<<incomming_data_buffer<<endl;

    //*********************************************************************************************
    //recieving Prime number
    int primeNumber;
    bytes_recieved = recv(socketfd, &primeNumber,sizeof(primeNumber), 0);
   // std::cout << bytes_recieved << " bytes recieved :" << std::endl ;
    std::cout <<endl<<"Alice:\t Prime Number recieved:\t"<< primeNumber << std::endl;

    //*********************************************************************************************
    //recieving 52 encrypted cards

    ssize_t bytes_recieved1;
    long long int incomming_data_buffer1[52];
    bytes_recieved1 = recv(socketfd, &incomming_data_buffer1,sizeof(incomming_data_buffer1), 0);

   // std::cout<<"endl<<Alice:\t Encrypted Cards"<<endl;
    for(int i=0;i<52 ;i++)
      {
       // std::cout << incomming_data_buffer1[i] << std::endl;

      }


    //*********************************************************************************************
    //selecting 10 out of 52 and encrypt Alice's 5 cards with her public key

   long long int phi = primeNumber-1;
   long long int publicKey =generateEncryptionKey(2,phi);
      while(GCD(publicKey,phi)!=1)
         publicKey =generateEncryptionKey(2,phi);

  // long long int encryptedmsg;

   long long int selectedCards[10];

   //*********************************************************************************************
  // 1st 5 are Alice's card. se
   long long int cardPositionAlice[5];

   cout<<"Alice :\t My cards\n";
     for(int i=0;i<5 ;i++)
       {
       cardPositionAlice[i] =rand()%(52);
      long long int pos=cardPositionAlice[i];
       // cout << "Card Pos: " <<pos<<endl;
         long long int encryptedmsg = encryptMsg(incomming_data_buffer1[pos],publicKey,primeNumber);
         selectedCards[i] = encryptedmsg;
         std::cout << selectedCards[i] << std::endl;
       }


     //*********************************************************************************************
     // Cards from position 5 to 10 are Bob's card choosen by Alice
      cout<<endl<<"Alice:\t Bob's Cards\n";
      for(int i=5;i<10 ;i++)
       {
         long long int cardPosition=rand()%(52);
         //cout << "Card Pos: " <<cardPosition<<endl;
         selectedCards[i] =  incomming_data_buffer1[cardPosition];;
         std::cout << selectedCards[i] << std::endl;

       }

    //*********************************************************************************************
    //send all 10 cards to Bob
    bytes_sent = send(socketfd, &selectedCards, sizeof(selectedCards), 0);

    //*********************************************************************************************
    // Sending Alice's indices to Bob
    bytes_sent = send(socketfd, &cardPositionAlice, sizeof(cardPositionAlice), 0);

    //*********************************************************************************************
    // Alice recieves back 5 cards from bob

    //the issue is here

    ssize_t bytes_recieved3;
    long long int incomming_data_buffer3[5];
    bytes_recieved3 = recv(socketfd, &incomming_data_buffer3,sizeof(incomming_data_buffer3), 0);
    if (bytes_recieved3== 0) std::cout << "host shut down." << std::endl ;
    if (bytes_recieved3 == -1)std::cout << "recieve error!" << std::endl ;


    for(int i=0;i<5 ;i++)
      {

       // if(i==0)
       // std::cout<<"My encrypted Cards:"<<endl;
       // std::cout << incomming_data_buffer3[i] << std::endl;

      }


    //*********************************************************************************************
    // decrypt them
    long long int privateKey = generateDecryptionKey(publicKey,phi);
    vector<long long int> encryptedCards;

    for ( int i = 0; i < 5; i++)
    {
       // if(i==0)
         //   cout<<"MyCards"<<endl;
            encryptedCards.push_back(incomming_data_buffer3[i]);
             // std::cout<< encryptedCards[i]<< std::endl;

    }

    cout<<endl<<"Alice:\t My cards values after decryption\n";


    long long int  AliceCardValues[5];
    vector<long long int> decryptedCardsAll = DecryptAllCards(encryptedCards,privateKey,primeNumber);
    for(int i=0;i<5;i++)
    {
        AliceCardValues[i]=decryptedCardsAll[i];
        cout<<decryptedCardsAll[i]<<endl;

    }

    //*********************************************************************************************
    //sending Alice's cards

    ssize_t bytes_sent9;
    bytes_sent9 = send(socketfd, &AliceCardValues, sizeof(AliceCardValues), 0);



    //*********************************************************************************************
    //summing up Alice's cards

   long long int sumAlice=0;
    for(int i=0;i<5;i++)
    {
        sumAlice=sumAlice+decryptedCardsAll[i];

    }

    cout<<endl<<"Alice :\t Sum of my cards is:\t\t"<<sumAlice<<endl;


    //*********************************************************************************************
    //sending sum of Alice's cards

    ssize_t bytes_sent3;
    bytes_sent3 = send(socketfd, &sumAlice, sizeof(sumAlice), 0);

       bytes_sent = send(socketfd, &sumAlice, sizeof(sumAlice), 0);

    //*********************************************************************************************
    //recieving Bob's card sum
   long long int BobSCardsSum;
    ssize_t bytes_recieved4;
    bytes_recieved4 = recv(socketfd, &BobSCardsSum,sizeof(BobSCardsSum), 0);
    std::cout <<"\t Sum of Bob's' cards is:\t"<< BobSCardsSum<< std::endl;


    //*********************************************************************************************
    //Comparing sum

    if(sumAlice>BobSCardsSum)
            cout<<" \t Wohooo!!! I win :), Bob lost the game! :P"<<endl;
     else
           cout<<"\t Bob You won and I lost the game!! :("<<endl;


    //*********************************************************************************************
    //Closing message
      cout<<endl<<" Game finished!!"<<endl;


   // If no data arrives, the program will just wait here until some data arrives.
    if (bytes_recieved == 0) std::cout << "host shut down." << std::endl ;
    if (bytes_recieved == -1)std::cout << "recieve error!" << std::endl ;

    std::cout << "Receiving complete. Closing socket..." << std::endl;
    freeaddrinfo(host_info_list);
    close(socketfd);

}
