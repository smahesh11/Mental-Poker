#include <iostream>
#include <cstring>      // Needed for memset
#include <sys/socket.h> // Needed for the socket functions
#include <netdb.h>      // Needed for the socket functions
#include <unistd.h>
#include<string>
#include<math.h>
#include<vector>
#include<fstream>
#include<time.h>
#include<stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>

using namespace std;


struct passwd *pw = getpwuid(getuid());
   const char *homedir = pw->pw_dir;
   std::string h = std::string(homedir);
   std::string PrimesLocation = h + "/primes.txt";


long  long int pickRandomPrimes()
{
    vector<string> primeVector;
    srand (time(NULL));
    long long int   countOfPrimes=0;

    //get primes file size
    string line;
        ifstream primesfile1(PrimesLocation.c_str());

        if(primesfile1.is_open()){
            while(!primesfile1.eof()){
                getline(primesfile1,line);
               // cout<< line << endl;
                countOfPrimes++;
            }
            primesfile1.close();
        }

    string num;
    //read from file and store in array
    ifstream readPrimes (PrimesLocation.c_str());
     if (readPrimes.is_open())
     {
     while ( getline (readPrimes,num) )
     {
     // cout << line << '\n';
      primeVector.push_back(num);
     }
     readPrimes.close();
     }

     long long int pos1=rand()%(countOfPrimes-1);
     //long int pos2=rand()%(countOfPrimes-1);

      string str1=primeVector[pos1];
    //  cout<<""<<str1;
     long  long int pnum1 = atoi(str1.c_str());
   //  cout<<pnum1;
      return pnum1;
}



//method to calculate gcd for public key
unsigned GCD(unsigned u, unsigned v) {
    while ( v != 0) {
        unsigned r = u % v;
        u = v;
        v = r;
    }
    return u;
}

//method to generate public key
long long int generateEncryptionKey(long long int a, long long int b)
{
    return rand()%(b-a)+a;
}

//method to perform fing a^b mod c
long long int modPow(long long int card,long long int skey, long long int prime)
{
    long long int y = 1;
    long long int u = card % prime;

    while(skey != 0){
       if(skey % 2 == 1) y = (y*u) % prime;
       skey = floor(skey/2);
       u = (u*u) % prime;
    }
    return y;
}

//method to generate decryption key
long long int generateDecryptionKey(long long int a, long long int m)
{
        a %= m;
        for(long long int x = 1; x < m; x++) {
            if((a*x) % m == 1) return x;
        }

}

//method to encrypt one message
long long int encryptMsg(long long int card,long long int skey, long long int prime)
{
    long long int encryptedMsg = modPow(card,skey,prime);
    return encryptedMsg;
}

//method to decrypt one message
long long int decryptMsg(long long int card,long long int dkey, long long int prime)
{
    long long int encryptedMsg = modPow(card,dkey,prime);
    return encryptedMsg;
}

//method to generate deck of cards
vector<long long int> generateDeck()
{
    vector <long long int> deckOfCards;
    for(int i=48;i<100;i++)
    {
         deckOfCards.push_back(i);
    }

    return deckOfCards;
}

//method to shuffele cards
vector<long long int> ShuffeledCards()
{
    vector <long long int> arr=generateDeck();
    srand ( time(NULL) );

       // Start from the last element and swap one by one. We don't
       // need to run for the first element that's why i > 0

           for (long int i=0; i<52; i++)
           {
                long int r = rand() % 52;  // generate a random position
                long int temp = arr[i];
                arr[i] = arr[r];
                arr[r] = temp;
           }


    return arr;
}

//method to encrypt multiple cards
vector<long long int> EncryptAllCards(vector<long long int> cards, long long int publicKey, long long int primeNumber)
{
     vector<long long int> encyptedcardsAll;
     cards=ShuffeledCards();

     for(int i=0;i<cards.size();i++)
     {
     encyptedcardsAll.push_back(modPow(cards[i],publicKey, primeNumber));
     }

     return encyptedcardsAll;
}

//method to decrypt multiple cards
vector<long long int> DecryptAllCards(vector<long long int> encryptedCards, long long int privateKey, long long int phi)
{
    vector<long long int> decryptedcardsAll;

    for(int i=0;i<encryptedCards.size();i++)
    {
    decryptedcardsAll.push_back(modPow(encryptedCards[i],privateKey, phi));
    }

    return decryptedcardsAll;
}






int main()
{

    int status;
    struct addrinfo host_info;       // The struct that getaddrinfo() fills up with data.
    struct addrinfo *host_info_list; // Pointer to the to the linked list of host_info's.

    // The MAN page of getaddrinfo() states "All  the other fields in the structure pointed
    // to by hints must contain either 0 or a null pointer, as appropriate." When a struct
    // is created in c++, it will be given a block of memory. This memory is not nessesary
    // empty. Therefor we use the memset function to make sure all fields are NULL.
    memset(&host_info, 0, sizeof host_info);

    std::cout << "Setting up the structs..."  << std::endl;

    host_info.ai_family = AF_UNSPEC;     // IP version not specified. Can be both.
    host_info.ai_socktype = SOCK_STREAM; // Use SOCK_STREAM for TCP or SOCK_DGRAM for UDP.
    host_info.ai_flags = AI_PASSIVE;     // IP Wildcard

    // Now fill up the linked list of host_info structs with google's address information.
    status = getaddrinfo(NULL, "5556", &host_info, &host_info_list);
    // getaddrinfo returns 0 on succes, or some other value when an error occured.
    // (translated into human readable text by the gai_gai_strerror function).
    if (status != 0)  std::cout << "getaddrinfo error" << gai_strerror(status) ;


    std::cout << "Creating a socket..."  << std::endl;
    int socketfd ; // The socket descripter
    socketfd = socket(host_info_list->ai_family, host_info_list->ai_socktype,
                      host_info_list->ai_protocol);
    if (socketfd == -1)  std::cout << "socket error " ;

    std::cout << "Binding socket..."  << std::endl;
    // we use to make the setsockopt() function to make sure the port is not in use
    // by a previous execution of our code. (see man page for more information)
    int yes = 1;
    status = setsockopt(socketfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
    status = bind(socketfd, host_info_list->ai_addr, host_info_list->ai_addrlen);
    if (status == -1)  std::cout << "bind error" << std::endl ;

    std::cout << "Listen()ing for connections..."  << std::endl;
    status =  listen(socketfd, 5);
    if (status == -1)  std::cout << "listen error" << std::endl ;


    int new_sd;
    struct sockaddr_storage their_addr;
    socklen_t addr_size = sizeof(their_addr);
    new_sd = accept(socketfd, (struct sockaddr *)&their_addr, &addr_size);
    if (new_sd == -1)
    {
        std::cout << "listen error" << std::endl ;
    }
    else
    {
        std::cout << "Connection accepted. Using new socketfd : "  <<  new_sd << std::endl;
    }


    //start of game
    std::cout << "Waiting to recieve data..."  << std::endl;
    ssize_t bytes_recieved;
    char incomming_data_buffer[1000];
    bytes_recieved = recv(new_sd, incomming_data_buffer,1000, 0);
    // If no data arrives, the program will just wait here until some data arrives.
    if (bytes_recieved == 0) std::cout << "host shut down." << std::endl ;
    if (bytes_recieved == -1)std::cout << "recieve error!" << std::endl ;
   // std::cout << bytes_recieved << " bytes recieved :" << std::endl ;
    incomming_data_buffer[bytes_recieved] = '\0';
    std::cout << incomming_data_buffer << std::endl<<endl;

    //*********************************************************************************************
    //sending yes sure
    std::cout << "sending back a message..."  << std::endl;
    char *msg = "Bob: \t Yes sure!! Let me send you the large prime number";
    int len;
    ssize_t bytes_sent;
    len = strlen(msg);
    bytes_sent = send(new_sd, msg, len, 0);
   // cout<<"bytes"<<bytes_sent<<'\n';
    //**********************************************************************************************
    //sending  large prime number
    int primeNumber = pickRandomPrimes();
    cout << primeNumber <<endl;
    ssize_t bytes_sent1;
    bytes_sent1 = send(new_sd, &primeNumber, sizeof(primeNumber), 0);
  //  cout<<"bytes1"<<bytes_sent<<'\n';

    //**********************************************************************************************
    //encrypt cards
    long long int phi = primeNumber-1;

    long long int publicKey =generateEncryptionKey(2,phi);
    while(GCD(publicKey,phi)!=1)
      publicKey =generateEncryptionKey(2,phi);

      vector<long long int> shuffledCards=ShuffeledCards();
      vector<long long int> encryptedCardsAll= EncryptAllCards(shuffledCards,publicKey,primeNumber);
      //for(int i=0;i<52;i++)
      //    cout << shuffledCards[i] << endl;
      long long int msg1[52];
     // cout<<"Encrypted Cards";
      for ( int i = 0; i < 52; i++)
      {
                  msg1[i] = encryptedCardsAll[i];
                 // std::cout<< msg1[i]<<'\n';
      }


    //*********************************************************************************************
    //send 52 encrypted cards to Alice(encrypted by Bob's public key)
     bytes_sent1 = send(new_sd, &msg1, sizeof(msg1), 0);

    //**********************************************************************************************
    //Recieve 10 cards from Alice(encrypted by Alice's public key)

          ssize_t bytes_recieved1;
          long long int incomming_data_buffer1[10];
          bytes_recieved1 = recv(new_sd, &incomming_data_buffer1,sizeof(incomming_data_buffer1), 0);
          if (bytes_recieved1 == 0) std::cout << "host shut down." << std::endl ;
          if (bytes_recieved1 == -1)std::cout << "recieve error!" << std::endl ;
         // cout<<"Printing choosen values at server side:\n";
          //for(int i=0;i<10 ;i++)
          //  {
          //    std::cout << incomming_data_buffer1[i] << std::endl;
          //  }

     //**********************************************************************************************
     //Recieve Alice's indices

          long long int AlicesIndices[5];
         ssize_t bytes_recieved2;
         bytes_recieved2= recv(new_sd, &AlicesIndices,sizeof(AlicesIndices), 0);

         cout<<endl<<"Bob: \t Alice's indices:\t\n";
         for(int i=0;i<5;i++)
         {
             cout<<AlicesIndices[i]<<endl;
         }

    //**********************************************************************************************
    //Decrypt 5 cards out of the above recieved 10
    //long long int phi = primeNumber-1;
    long long int privateKey = generateDecryptionKey(publicKey,phi);
    //cout<<"privateKey"<<privateKey;
    vector<long long int> selectedCards;

    for ( int i = 0; i < 10; i++)
    {
                selectedCards.push_back( incomming_data_buffer1[i]);
                //std::cout <<"Printing all the values at server side "<< msg1[i]<< std::endl;

    }

    vector<long long int> decryptedCardsAll=DecryptAllCards(selectedCards,privateKey,primeNumber);
     cout<<endl<<"Bob: \t  All Decrypted Cards\n";
    for(int i=0;i<10;i++)
    {
        cout<<"\t"<<decryptedCardsAll[i]<<endl;

    }

     //*********************************************************************************************
    //send other 5 cards to Alice
   cout<<endl<<"Bob: \t Alice's cards"<<endl;
   long long int aliceCards1[5];

    for(int i=0;i<5;i++)
    {
        aliceCards1[i] = decryptedCardsAll[i];
        //cout<<decryptedCardsAll[i]<<"\t";
        cout<<aliceCards1[i]<<endl;
    }

   ssize_t bytes_sent2;
   bytes_sent2 = send(new_sd, &aliceCards1, sizeof(aliceCards1), 0);
   //bytes_sent2= send(new_sd, &aliceCards1, sizeof(aliceCards1), 0);



   //*********************************************************************************************
   //summing up Bob's cards
   long long int sumBob=0;
   cout<<endl<< "Bob: \t My Cards\n";
   for(int i=0;i<5;i++)
   {
       cout << decryptedCardsAll[i+5]<<endl;
       sumBob=sumBob+decryptedCardsAll[i+5];

   }


    //*********************************************************************************************
    //receiving Alice's cards
    ssize_t bytes_recieved3;
    long long int AliceActualCCards[5];
    bytes_recieved3 = recv(new_sd, &AliceActualCCards,sizeof(AliceActualCCards), 0);
    cout<<endl<<"Bob: \t Recieved Alice's cards values\t\n";
    for(int i =0;i<5;i++)
    {
        cout<<AliceActualCCards[i]<<endl;
    }

    //*********************************************************************************************
     cout<<endl<<"Bob: \t Sum of my cards is:\t\t"<<sumBob<<endl;

    //*********************************************************************************************
   //recieving sum of Alice's card

   long long int AliceCardsSum;
   ssize_t bytes_recieved4;
   bytes_recieved4 = recv(new_sd, &AliceCardsSum,sizeof(AliceCardsSum), 0);
   std::cout <<" \t Sum of Alice's cards is:\t"<< AliceCardsSum<< std::endl;


   //*********************************************************************************************
   //sending sum of bob's cards

  long long int sumOfBobCards = sumBob;
   //cout << primeNumber <<endl;
   ssize_t bytes_sent3;
   bytes_sent3 = send(new_sd, &sumOfBobCards, sizeof(sumOfBobCards), 0);

   //***********************************************************************************************
   //Fraud detection
   bool flag=true;
   for(int i=0;i<5;i++)
   {
      long long x=AlicesIndices[i];
      //cout<<"posss"<<x<<endl;
       if(shuffledCards[x]!=AliceActualCCards[i])
       {
           //cout<<"sh"<<shuffledCards[x]<<'\t'<<"ali"<<AliceActualCCards[i]<<endl;
           flag=false;
          break;
       }

   }

   if(flag==true)
   {
         cout<<"\t No fraud!! Game honestly played"<<endl;

         if(AliceCardsSum>sumOfBobCards)
             cout<<" \t Alice You Win!!"<<"\t I lost the game!! :( \n"<<endl;
         else
             cout<<" \t Wohooo!!!  I Win!!"<<"\t Alice You lost the game!! :P \n"<<endl;
   }
   else
       cout<<" \t Alice! You cheated in the game!!\t"<<"I(Bob) won he game!"<<endl;



      //*********************************************************************************************
      //Closing message
        cout<<endl<<" Game finished!!"<<endl;

    //*********************************************************************************************
    //stop server
    std::cout << endl<<"Stopping server..." << std::endl;
    freeaddrinfo(host_info_list);
    close(new_sd);
    close(socketfd);

return 0 ;


}
